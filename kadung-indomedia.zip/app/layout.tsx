import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/header"
import Footer from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Kadung Indomedia - Digital Marketing Agency",
  description:
    "Kadung Indomedia adalah agensi digital marketing terpercaya yang menawarkan layanan SEO, Digital Ads, Publikasi Media, dan Pengembangan Website Bisnis.",
  keywords: "digital marketing, SEO, digital ads, publikasi media, pengembangan website, agensi marketing",
  openGraph: {
    title: "Kadung Indomedia - Digital Marketing Agency",
    description:
      "Kadung Indomedia adalah agensi digital marketing terpercaya yang menawarkan layanan SEO, Digital Ads, Publikasi Media, dan Pengembangan Website Bisnis.",
    url: "https://kadungindomedia.com",
    siteName: "Kadung Indomedia",
    locale: "id_ID",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <link rel="canonical" href="https://kadungindomedia.com" />
        <meta name="robots" content="index, follow" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Kadung Indomedia",
              url: "https://kadungindomedia.com",
              logo: "https://kadungindomedia.com/logo.png",
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+62-xxx-xxxx-xxxx",
                contactType: "customer service",
              },
              sameAs: [
                "https://facebook.com/kadungindomedia",
                "https://twitter.com/kadungindomedia",
                "https://instagram.com/kadungindomedia",
                "https://linkedin.com/company/kadungindomedia",
              ],
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <Header />
          <main className="min-h-screen">{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}
