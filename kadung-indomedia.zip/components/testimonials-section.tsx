import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

export default function TestimonialsSection() {
  const testimonials = [
    {
      id: 1,
      name: "Budi Santoso",
      position: "CEO, PT Maju Bersama",
      image: "/placeholder.svg?height=100&width=100&text=BS",
      content:
        "Kadung Indomedia telah membantu kami meningkatkan traffic website sebesar 200% dalam 6 bulan. Strategi SEO mereka sangat efektif dan tim mereka sangat profesional.",
      rating: 5,
    },
    {
      id: 2,
      name: "Siti Rahayu",
      position: "Marketing Director, Fashion Store",
      image: "/placeholder.svg?height=100&width=100&text=SR",
      content:
        "Kampanye digital ads yang dijalankan oleh Kadung Indomedia memberikan ROI yang luar biasa. Mereka benar-benar memahami target market kami dan mengoptimalkan anggaran dengan sangat baik.",
      rating: 5,
    },
    {
      id: 3,
      name: "Andi Wijaya",
      position: "Owner, Restoran Selera",
      image: "/placeholder.svg?height=100&width=100&text=AW",
      content:
        "Website baru yang dikembangkan oleh Kadung Indomedia tidak hanya terlihat profesional tetapi juga meningkatkan konversi reservasi online kami sebesar 80%. Sangat merekomendasikan!",
      rating: 4,
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">Apa Kata Klien Kami</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Kisah sukses dari bisnis yang telah bekerja sama dengan kami
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="border-0 shadow-lg bg-white dark:bg-gray-900">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>

                <p className="text-gray-700 dark:text-gray-300 mb-6 italic">"{testimonial.content}"</p>

                <div className="flex items-center">
                  <div className="mr-4">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      width={60}
                      height={60}
                      className="rounded-full"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 dark:text-white">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{testimonial.position}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
