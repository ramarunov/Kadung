import Image from "next/image"
import { CheckCircle } from "lucide-react"

export default function AboutSection() {
  const benefits = [
    "Tim ahli dengan pengalaman lebih dari 10 tahun",
    "Pendekatan berbasis data untuk hasil yang terukur",
    "Strategi yang disesuaikan dengan kebutuhan bisnis Anda",
    "Laporan transparan dan komunikasi yang jelas",
    "Teknologi terkini dan praktik terbaik industri",
  ]

  return (
    <section id="tentang" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-600/20 to-purple-400/20 rounded-2xl transform -rotate-3 scale-105" />
            <div className="relative rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=600&width=800&text=Tentang+Kami"
                alt="Tim Kadung Indomedia"
                width={800}
                height={600}
                className="w-full h-auto"
              />
            </div>

            {/* Experience badge */}
            <div className="absolute -bottom-6 -right-6 bg-purple-600 text-white rounded-lg shadow-lg p-4">
              <p className="text-3xl font-bold">10+</p>
              <p className="text-sm">Tahun Pengalaman</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
                Tentang Kadung Indomedia
              </h2>
              <div className="h-1 w-20 bg-purple-600 mb-6" />
            </div>

            <p className="text-lg text-gray-600 dark:text-gray-300">
              Kadung Indomedia adalah agensi digital marketing terpercaya yang berfokus pada pertumbuhan bisnis klien
              melalui strategi digital yang komprehensif dan terukur.
            </p>

            <p className="text-lg text-gray-600 dark:text-gray-300">
              Didirikan pada tahun 2013, kami telah membantu lebih dari 500 bisnis dari berbagai industri untuk
              meningkatkan presence online mereka, mendapatkan lebih banyak pelanggan, dan meningkatkan pendapatan.
            </p>

            <div className="space-y-3 mt-6">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-purple-600 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-700 dark:text-gray-200">{benefit}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
