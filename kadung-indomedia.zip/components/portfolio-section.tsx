import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const categories = [
  { id: "all", label: "Semua" },
  { id: "seo", label: "SEO" },
  { id: "ads", label: "Digital Ads" },
  { id: "web", label: "Website" },
  { id: "media", label: "Publikasi Media" },
]

const projects = [
  {
    id: 1,
    title: "Optimasi SEO E-commerce Fashion",
    category: "seo",
    image: "/placeholder.svg?height=400&width=600&text=SEO+Project",
    result: "Peningkatan traffic organik 200% dalam 6 bulan",
  },
  {
    id: 2,
    title: "Kampanye Google Ads Properti",
    category: "ads",
    image: "/placeholder.svg?height=400&width=600&text=Ads+Project",
    result: "ROAS 350% dengan 120+ leads per bulan",
  },
  {
    id: 3,
    title: "Website Restoran Premium",
    category: "web",
    image: "/placeholder.svg?height=400&width=600&text=Web+Project",
    result: "Peningkatan reservasi online sebesar 80%",
  },
  {
    id: 4,
    title: "Publikasi di 20+ Media Nasional",
    category: "media",
    image: "/placeholder.svg?height=400&width=600&text=Media+Project",
    result: "Jangkauan 2 juta+ pembaca dalam 1 bulan",
  },
  {
    id: 5,
    title: "Optimasi SEO Lokal Klinik",
    category: "seo",
    image: "/placeholder.svg?height=400&width=600&text=SEO+Local+Project",
    result: "Peringkat #1 untuk 30+ keyword lokal",
  },
  {
    id: 6,
    title: "Kampanye Facebook & Instagram Ads",
    category: "ads",
    image: "/placeholder.svg?height=400&width=600&text=Social+Ads+Project",
    result: "CPL turun 40% dengan konversi naik 25%",
  },
]

export default function PortfolioSection() {
  return (
    <section id="portofolio" className="py-16 md:py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">Portofolio Proyek Kami</h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Lihat bagaimana kami membantu bisnis mencapai tujuan digital marketing mereka
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <div className="flex justify-center mb-12">
            <TabsList className="bg-gray-100 dark:bg-gray-800">
              {categories.map((category) => (
                <TabsTrigger key={category.id} value={category.id} className="px-4 py-2 text-sm md:text-base">
                  {category.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="all" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project) => (
                <ProjectCard key={project.id} project={project} categories={categories} />
              ))}
            </div>
          </TabsContent>

          {categories.slice(1).map((category) => (
            <TabsContent key={category.id} value={category.id} className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects
                  .filter((project) => project.category === category.id)
                  .map((project) => (
                    <ProjectCard key={project.id} project={project} categories={categories} />
                  ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}

function ProjectCard({ project, categories }) {
  return (
    <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
      <div className="relative overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg"}
          alt={project.title}
          width={600}
          height={400}
          className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
          <p className="text-white font-medium">{project.result}</p>
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{project.title}</h3>
        <p className="text-sm text-purple-600 dark:text-purple-400 font-medium uppercase">
          {categories.find((c) => c.id === project.category)?.label}
        </p>
      </CardContent>
    </Card>
  )
}
