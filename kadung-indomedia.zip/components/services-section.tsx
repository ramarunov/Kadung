import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, BarChart3, Newspaper, Globe, Megaphone, PenTool } from "lucide-react"

export default function ServicesSection() {
  const services = [
    {
      icon: <Search className="h-10 w-10 text-purple-600" />,
      title: "Search Engine Optimization (SEO)",
      description:
        "Tingkatkan peringkat website Anda di mesin pencari dan dapatkan traffic organik yang berkelanjutan.",
    },
    {
      icon: <BarChart3 className="h-10 w-10 text-purple-600" />,
      title: "Digital Advertising",
      description:
        "Kampanye iklan digital yang tepat sasaran di Google Ads, Facebook Ads, Instagram Ads, dan platform lainnya.",
    },
    {
      icon: <Newspaper className="h-10 w-10 text-purple-600" />,
      title: "Publikasi Media",
      description:
        "Publikasikan konten bisnis Anda di berbagai media online terkemuka untuk meningkatkan kredibilitas dan awareness.",
    },
    {
      icon: <Globe className="h-10 w-10 text-purple-600" />,
      title: "Pengembangan Website Bisnis",
      description: "Bangun website profesional yang responsif, cepat, dan dioptimalkan untuk konversi.",
    },
    {
      icon: <Megaphone className="h-10 w-10 text-purple-600" />,
      title: "Social Media Marketing",
      description: "Kelola dan kembangkan presence brand Anda di platform media sosial untuk meningkatkan engagement.",
    },
    {
      icon: <PenTool className="h-10 w-10 text-purple-600" />,
      title: "Content Marketing",
      description: "Strategi konten yang menarik dan relevan untuk menjangkau dan mempertahankan audiens target Anda.",
    },
  ]

  return (
    <section id="layanan" className="py-16 md:py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900 dark:text-white">
            Layanan Digital Marketing Kami
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Solusi komprehensif untuk membantu bisnis Anda tumbuh di era digital
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-gray-50 dark:bg-gray-800"
            >
              <CardHeader>
                <div className="mb-4">{service.icon}</div>
                <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 dark:text-gray-300 text-base">
                  {service.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
