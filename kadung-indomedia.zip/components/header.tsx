"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const isMobile = useMobile()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? "bg-white/95 shadow-md backdrop-blur-sm dark:bg-gray-900/95" : "bg-transparent"}`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="/placeholder.svg?height=40&width=40"
              alt="Kadung Indomedia Logo"
              width={40}
              height={40}
              className="h-10 w-auto"
            />
            <span className="text-xl font-bold text-gray-900 dark:text-white">Kadung Indomedia</span>
          </Link>

          {isMobile ? (
            <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Toggle menu">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          ) : (
            <nav className="hidden md:flex items-center space-x-8">
              <Link
                href="/"
                className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              >
                Beranda
              </Link>
              <Link
                href="#layanan"
                className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              >
                Layanan
              </Link>
              <Link
                href="#tentang"
                className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              >
                Tentang Kami
              </Link>
              <Link
                href="#portofolio"
                className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              >
                Portofolio
              </Link>
              <Link
                href="#kontak"
                className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              >
                Kontak
              </Link>
              <Button asChild>
                <Link href="#konsultasi">Konsultasi Gratis</Link>
              </Button>
            </nav>
          )}
        </div>

        {/* Mobile menu */}
        {isMobile && isMenuOpen && (
          <nav className="mt-4 flex flex-col space-y-4 pb-4">
            <Link
              href="/"
              className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Beranda
            </Link>
            <Link
              href="#layanan"
              className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Layanan
            </Link>
            <Link
              href="#tentang"
              className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Tentang Kami
            </Link>
            <Link
              href="#portofolio"
              className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Portofolio
            </Link>
            <Link
              href="#kontak"
              className="text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Kontak
            </Link>
            <Button asChild className="w-full">
              <Link href="#konsultasi" onClick={() => setIsMenuOpen(false)}>
                Konsultasi Gratis
              </Link>
            </Button>
          </nav>
        )}
      </div>
    </header>
  )
}
